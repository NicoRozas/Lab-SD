			INSTRUCCIONES

*****************************************************************
*							    	*
*  El laboratorio est� contenido en la carpeta Distribuidos 	*
*	-Para cambiar el n�mero de particiones debe ir a    	*
*	 la clase Padre.java en la linea 39, el atributo    	*
*	 lleva como nombre canParticiones y es un int y 	*
*	 como m�ximo son 127 particiones.		      	*
*	-El puerto al que se debe conectar el cliente es    	*
*	 al puerto 5000, en caso de cualquier problema en   	*
*	 el proyecto se cre� un cliente que est� conectado  	*
*	 a la clase Padre.java quien hace de servidor.		*
*	-El cliente debe mandar mensaje "fin" para terminar	*
*	 la ejecuci�n del servidor			    	*
*							    	*
*****************************************************************